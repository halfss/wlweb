# Denis Brojan, Ljubljana, Slovenia, 2015-2018
# The original code by Sebastien Jodogne, University Hospital of Liege,
# Belgium, was modified in order to further extend its usabilty.
# Changes include: modification of the authentication procedure,
# modification of functions that are used to get data from the
# orthanc server, addition of new functions.
# The same GNU General Public License applies to the modified code.
# The original RestToolbox code is contained in the same directory for reference.

############################################################################
#############################################################################

# Orthanc - A Lightweight, RESTful DICOM Store
# Copyright (C) 2012-2016 Sebastien Jodogne, Medical Physics
# Department, University Hospital of Liege, Belgium
#
# This program is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.


import httplib2
import json
import sys
import base64
import tempfile
import numpy as np
import datetime


TEMP_DCM_FOLDER = "temp_dcm_archive"

if (sys.version_info >= (3, 0)):
    from urllib.parse import urlencode
else:
    from urllib import urlencode


_credentials = None
_auth = ""

def _DecodeJson(s):
    try:
        if (sys.version_info >= (3, 0)):
            return json.loads(s.decode())
        else:
            return json.loads(s)
    except:
        return s


def SetCredentials(username, password):
    global _credentials, _auth
    _credentials = (username, password)
    _auth = base64.encodebytes( (_credentials[0] + ':' + _credentials[1] ).encode())

def _SetupCredentials(h):
    global _credentials, _auth
    if _credentials != None:
        h.add_credentials(_credentials[0], _credentials[1])

def DoGet(uri, data = {}, interpretAsJson = True):
    d = ''
    if len(data.keys()) > 0:
        d = '?' + urlencode(data)

    h = httplib2.Http()
    _SetupCredentials(h)

    headers = {'Accept': 'application/json',
               'Content-Type': 'application/json',
               'Authorization' : 'Basic ' + _auth.decode() }
    resp, content = h.request(uri + d, 'GET', headers=headers)
    if not (resp.status in [ 200 ]):
        raise Exception(resp.status)
    elif not interpretAsJson:
        return content.decode()
    else:
        return _DecodeJson(content)


def _DoPutOrPost(uri, method, data, contentType):
    h = httplib2.Http()
    _SetupCredentials(h)

    if isinstance(data, str):
        body = data
        if len(contentType) != 0:
            headers = { 'content-type' : contentType,
                        'Authorization' : 'Basic ' + _auth.decode() }
        else:
            headers = { 'content-type' : 'text/plain',
                        'Authorization' : 'Basic ' + _auth.decode()}
    else:
        body = json.dumps(data)
        headers = { 'content-type' : 'application/json',
                    'Authorization' : 'Basic ' + _auth.decode()}

    resp, content = h.request(
        uri, method,
        body = body,
        headers = headers)

    if not (resp.status in [ 200, 302 ]):
        raise Exception(resp.status)
    else:
        return _DecodeJson(content)


def DoDelete(uri):
    h = httplib2.Http()
    _SetupCredentials(h)
    headers = { 'Authorization' : 'Basic ' + _auth.decode() }

    resp, content = h.request(uri, 'DELETE', headers=headers)

    if not (resp.status in [ 200 ]):
        raise Exception(resp.status)
    else:
        return _DecodeJson(content)


def DoPut(uri, data = {}, contentType = ''):
    return _DoPutOrPost(uri, 'PUT', data, contentType)


def DoPost(uri, data = {}, contentType = ''):
    return _DoPutOrPost(uri, 'POST', data, contentType)


def GetPatientIds(uri, interpretAsJson = True):

    h = httplib2.Http()
    _SetupCredentials(h)
    headers = {'Accept': 'application/json',
               'Content-Type': 'application/json',
               'Authorization' : 'Basic ' + _auth.decode()}

    resp, content = h.request(uri + "/patients", 'GET', headers=headers)

    if not (resp.status in [ 200 ]):
        raise Exception(resp.status)
    elif not interpretAsJson:
        return content.decode()
    else:
        return _DecodeJson(content)

def GetPatientData(uri, patient_id, interpretAsJson = True):

    patient_properties = []

    for p in patient_id:
        h = httplib2.Http()
        _SetupCredentials(h)
        headers = {'Accept': 'application/json',
                   'Content-Type': 'application/json',
                   'Authorization' : 'Basic ' + _auth.decode(),
                   'Connection': 'Close'}

        resp, content = h.request(uri + "/patients/"+p, 'GET', headers=headers)

        if not (resp.status in [ 200 ]):
            raise Exception(resp.status)
        elif not interpretAsJson:
            patient_properties.append(content.decode())
        else:
            patient_properties.append(_DecodeJson(content))
    return patient_properties


def GetStudies(uri, studies, interpretAsJson = True):
    study_data = []

    for p in studies:
        h = httplib2.Http()
        _SetupCredentials(h)
        headers = {'Accept': 'application/json',
                   'Content-Type': 'application/json',
                   'Authorization' : 'Basic ' + _auth.decode(),
                   'Connection': 'Close'}

        resp, content = h.request(uri + "/studies/"+p, 'GET', headers=headers)

        if not (resp.status in [ 200 ]):
            raise Exception(resp.status)
        elif not interpretAsJson:
            study_data.append(content.decode())
        else:
            study_data.append(_DecodeJson(content))
    return study_data

def GetSeries(uri, series, interpretAsJson = True):
    series_data = []

    for p in series:
        h = httplib2.Http()
        _SetupCredentials(h)
        headers = {'Accept': 'application/json',
                   'Content-Type': 'application/json',
                   'Authorization' : 'Basic ' + _auth.decode(),
                   'Connection': 'Close'}

        resp, content = h.request(uri + "/series/"+p, 'GET', headers=headers)

        if not (resp.status in [ 200 ]):
            raise Exception(resp.status)
        elif not interpretAsJson:
            series_data.append(content.decode())
        else:
            series_data.append(_DecodeJson(content))
    return series_data

def GetInstances(uri, instances, interpretAsJson = True):
    instance_data = []

    for p in instances:
        h = httplib2.Http()
        _SetupCredentials(h)
        headers = {'Accept': 'application/json',
                   'Content-Type': 'application/json',
                   'Authorization' : 'Basic ' + _auth.decode(),
                   'Connection': 'Close'}

        resp, content = h.request(uri + "/instances/"+p+"/simplified-tags", 'GET', headers=headers)

        if not (resp.status in [ 200 ]):
            raise Exception(resp.status)
        elif not interpretAsJson:
            instance_data.append(content.decode())
        else:
            instance_data.append(_DecodeJson(content))
    return instance_data


def GetDcmZip(uri, series, interpretAsJson = True):
    # Get filepaths, ordered in sequence of datetime! Ordering is important for analysis (Winston Lutz etc.)
    h = httplib2.Http()
    _SetupCredentials(h)
    headers = {'Accept': 'application/json',
               'Content-Type': 'application/json',
               'Authorization' : 'Basic ' + _auth.decode(),
               'Connection': 'Close'}

    resp, content = h.request(uri + "/series/"+series, 'GET', headers=headers)
    if not (resp.status in [ 200 ]):
        raise Exception(resp.status)
    elif not interpretAsJson:
        data = content.decode()
    else:
        data = _DecodeJson(content)

    instances = data["Instances"]

    inst_temp = GetInstances(uri, instances)

    instance_datetime = []
    instance_datetime_order = []
    epoch = datetime.datetime.utcfromtimestamp(0)

    for ii in inst_temp:
        try:
            tt = ii["ContentDate"]+ii["ContentTime"]
            try:
                milisec = tt[15:17]
            except:
                milisec = "00"
        except:
            try:
                tt = ii["InstanceAcquisitionDate"]+ii["InstanceAcquisitionTime"]
                try:
                    milisec = tt[15:17]
                except:
                    milisec = "00"
            except:
                try:
                    tt = ii["InstanceCreationDate"]+ii["InstanceCreationTime"]
                    try:
                        milisec = tt[15:17]
                    except:
                        milisec = "00"
                except:
                    instance_datetime.append("Unknown")
                    instance_datetime_order.append(int((epoch - epoch).total_seconds()*1000))
        instance_datetime.append(datetime.datetime.strptime(tt[0:14], "%Y%m%d%H%M%S").strftime("%d/%m/%Y | %H:%M:%S.")+milisec)

        try:
            instance_datetime_order.append(int((datetime.datetime.strptime(tt,  "%Y%m%d%H%M%S.%f") - epoch).total_seconds()*1000))
        except:
            instance_datetime_order.append(int((datetime.datetime.strptime(tt,  "%Y%m%d%H%M%S") - epoch).total_seconds()*1000))

    order = np.argsort(instance_datetime_order)

    instances = list(np.asarray(instances)[order])
    file_paths = []

    # Now save each file twice in a subfolder
    for i in instances:
        temp_folder = tempfile.mkdtemp(prefix=i+"_", dir=TEMP_DCM_FOLDER)
        temp_file1 = tempfile.NamedTemporaryFile(delete=False, prefix=i+"_", suffix=".DCM", dir=temp_folder)
        temp_file2 = tempfile.NamedTemporaryFile(delete=False, prefix=i+"_second_", suffix=".DCM", dir=temp_folder)
        file = DoGet(uri + "/instances/" + i + "/file")

        with open(temp_file1.name, 'wb') as dst:
            dst.write(file)
        temp_file1.close()

        with open(temp_file2.name, 'wb') as dst:
            dst.write(file)
        temp_file2.close()

        file_paths.append(temp_folder)
    return file_paths

