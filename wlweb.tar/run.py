# Copyright 2018 Denis Brojan, Ljubljana, Slovenia
#
# Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
# documentation files (the "Software"), to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all copies or substantial portions
# of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
# TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
# CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
This module is the main module. Run it with the following command: python run.py
"""

from bottle import Bottle, request, redirect
from bottle import static_file
from bottle import template
import json
from threading import Lock
import os
import gc
import datetime
import numpy as np
import warnings
import shutil
import RestToolbox_modified as RestToolbox

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import patches

import mpld3

# pylinac v2.1.0
from pylinac import WinstonLutz as WinstonLutz
from pylinac.core import image as pylinacimage

plt.style.use('classic')  # To revert back to matplotlib 1.0 style


# Set string for the header of HTML pages:
INSTITUTION = "Put some text here"

# IP address and port where the web interface will be available:
IP_ADDRESS = "127.0.0.1"
PORT = 8080

# IP adress and port where the http dicom server will be available:
# If dicom server will run on a different computer, change ORTHANC_IP
ORTHANC_IP = "127.0.0.1"
ORTHANC_PORT = 8042

# Credentials for accessing web interface:
USERNAME = "username"
PASSWORD = "password"

# Credentials for accessing orthanc server:
# Orthanc credentials must match with configWin.json!
USERNAME_ORTHANC = "orthancuser"
PASSWORD_ORTHANC = "orthancpass"

# Passing rate in mm for the Winston-Lutz test
PASS_RATE = 1.5  # If more than this, the test is "failed"
SUCCESS_RATE = 1.0  # If more than this, the test is "borderline", but not "failed"


# Url to some mpld3 library
D3_URL = "/js/d3.v3.min.js"
MPLD3_URL = "/js/mpld3.v0.3.min.js"

ORTHANC_URL = "http://"+str(ORTHANC_IP) + ":" + str(ORTHANC_PORT)
RestToolbox.SetCredentials(USERNAME_ORTHANC, PASSWORD_ORTHANC)

# Working directory
WLWEB_FOLDER = "/" + os.getcwd().split(os.sep)[-1]


def delete_files_in_path(file_paths):
    # Function for deleting images after transfer
    for ff in file_paths:
        try:
            shutil.rmtree(ff)
        except:
            warnings.warn(ff + " could not be deleted")
            continue

def Read_from_dcm_database():
    # Function that reads from the orthanc database and gives a list of patients.
    try:
        p = RestToolbox.GetPatientIds(ORTHANC_URL)
        data = RestToolbox.GetPatientData(ORTHANC_URL, p)
    except:
        print("Orthanc is refusing connection.")
        raise

    names = []
    IDs = []
    birthdate = []
    lastupdate = []
    for d in data:
        try:
            names.append(d["MainDicomTags"]["PatientName"].replace("^", " "))
        except:
            names.append("UnknownPatient")
        try:
            IDs.append(d["MainDicomTags"]["PatientID"])
        except:
            IDs.append("UnknownPatientID")
        try:
            birthdate.append(d["MainDicomTags"]["PatientBirthDate"])
        except:
            birthdate.append("UnknownBirthDate")
        try:
            lastupdate.append(d["LastUpdate"])
        except:
            lastupdate.append("UnknownLastUpdate")

    variables = {"orthanc_id": p,
                 "names": names,
                 "IDs": IDs,
                 "orthanc_url": ORTHANC_URL,
                 "institution": INSTITUTION,
                 "wlweb_folder": WLWEB_FOLDER
                 }
    return variables

def delete_figure(fig_list):
    # Function for deleting matplotlib figures
    for f in fig_list:
        plt.close(f)
        plt.clf()

def clip_around_image(img, clip_box):
    # Function that forces edges of the images to have background values
    img_size = img.shape
    phy_size = img.physical_shape
    background = img.array.min()
    if clip_box != 0:
        if (clip_box > phy_size[0]) or (clip_box > phy_size[1]):
            raise ValueError("Clipbox larger than the image itself")
        n_tb = int((img_size[0] - clip_box*img.dpmm)/2)  # Top bottom edge
        n_lr = int((img_size[1] - clip_box*img.dpmm)/2)  # Left right edge
        img.array[:, 0:n_lr] = background
        img.array[:, -n_lr:] = background
        img.array[0:n_tb, :] = background
        img.array[-n_tb:, :] = background


# Here start the bottle server
app = Bottle()

@app.get('/<filename:re:.*\.(css)>')
def stylesheets(filename):
    # Serve css files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(map)>')
def stylesheets_map(filename):
    # Serve css files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(ttf)>')
def font_bootstrap(filename):
    # Serve font files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(woff)>')
def font_bootstrap_woff(filename):
    # Serve font files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(woff2)>')
def font_bootstrap_woff2(filename):
    # Serve font files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(js)>')
def javascript(filename):
    # Serve js files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(html)>')
def html(filename):
    # Serve html files
    return static_file(filename, root='static')

@app.get('/<filename:re:.*\.(png)>')
def png(filename):
    # Serve png files
    return static_file(filename, root='static')

@app.error(500)
def custom500(error):
    return template("error_template", {"error_message": "Unknown error. Contact your administrator.",
                                       "qaserver_folder": WLWEB_FOLDER })

@app.route('/')
def redirect_to_login():
    redirect(WLWEB_FOLDER + "/winstonlutz")

@app.route(WLWEB_FOLDER)
def redirect_to_login2():
    redirect(WLWEB_FOLDER + "/winstonlutz")

@app.route(WLWEB_FOLDER + "/winstonlutz")
def login_form():
    # Serve login page with form request
    return template("login", {"wlweb_folder": WLWEB_FOLDER,
                              "institution": INSTITUTION})

@app.route(WLWEB_FOLDER + "/winstonlutz", method='POST')
def login_submit():
    # Get form data from login page
    username = request.forms.get('username')
    password = request.forms.get('password')
    if username == USERNAME and password == PASSWORD:
        try:
            variables = Read_from_dcm_database()
            return template("winston_lutz", variables)
        except ConnectionError:
            return template("error_template", {"error_message": "Orthanc is refusing connection.",
                                               "wlweb_folder": WLWEB_FOLDER})
    else:
        return template("error_template", {"error_message": "User not recognized.",
                                           "wlweb_folder": WLWEB_FOLDER})

@app.route(WLWEB_FOLDER + '/searchStudies/<s>', method="POST")
def livesearch_study(s):
    # Function to get studies and return them to the interface
    data = RestToolbox.GetPatientData(ORTHANC_URL, [s])
    studies = data[0]["Studies"]
    data_s = RestToolbox.GetStudies(ORTHANC_URL, studies)
    study_names = []

    for p in data_s:
        try:
            name_id = p["MainDicomTags"]["StudyID"]
        except:
            name_id = ""
        try:
            name_desc = " (" + p["MainDicomTags"]["StudyDescription"] + ")"
        except:
            name_desc = ""
        if name_desc == "" and name_id == "":
            name_id = "Undefined"
        study_names.append(name_id + name_desc)
    return json.dumps((studies, study_names))

@app.route(WLWEB_FOLDER + '/searchSeries/<s>', method="POST")
def livesearch_series(s):
    # Function to get series and return to the interface
    data = RestToolbox.GetStudies(ORTHANC_URL, [s])
    series = data[0]["Series"]
    data_s = RestToolbox.GetSeries(ORTHANC_URL, series)
    series_names = []

    for p in data_s:
        try:
            ser_num = " (" + p["MainDicomTags"]["SeriesNumber"] + ")"
        except:
            ser_num = ""
        try:
            ser_desc = p["MainDicomTags"]["SeriesDescription"]
        except:
            ser_desc = ""
        if ser_num == "" and ser_desc == "":
            ser_num = "Undefined"
        series_names.append(ser_desc + ser_num)
    return json.dumps((series, series_names))

@app.route(WLWEB_FOLDER + '/searchInstances/<s>', method="POST")
def livesearch_instances(s):
    # Function to get single dicom files
    p = RestToolbox.GetSeries(ORTHANC_URL, [s])[0]
    num_instances = []
    instances = p["Instances"]
    num_instances = len(instances)
    inst_temp = RestToolbox.GetInstances(ORTHANC_URL, instances)
    instance_datetime = []
    instance_datetime_order = []
    instance_num = []
    epoch = datetime.datetime.utcfromtimestamp(0)

    for ii in inst_temp:
        try:
            tt = ii["ContentDate"] + ii["ContentTime"]
            try:
                milisec = tt[15:17]
            except:
                milisec = "00"
        except:
            try:
                tt = ii["InstanceAcquisitionDate"] + ii["InstanceAcquisitionTime"]
                try:
                    milisec = tt[15:17]
                except:
                    milisec = "00"
            except:
                try:
                    tt = ii["InstanceCreationDate"] + ii["InstanceCreationTime"]
                    try:
                        milisec = tt[15:17]
                    except:
                        milisec = "00"
                except:
                    instance_datetime.append("Unknown")
                    instance_datetime_order.append(int((epoch - epoch).total_seconds()*1000))
        instance_datetime.append(datetime.datetime.strptime(tt[0:14], "%Y%m%d%H%M%S").strftime("%d/%m/%Y | %H:%M:%S.")+milisec)

        try:
            instance_datetime_order.append(int((datetime.datetime.strptime(tt,  "%Y%m%d%H%M%S.%f") - epoch).total_seconds()*1000))
        except:
            instance_datetime_order.append(int((datetime.datetime.strptime(tt,  "%Y%m%d%H%M%S") - epoch).total_seconds()*1000))

        try:
            manufact = ii["Manufacturer"]
        except:
            manufact = "Undefined"

        if manufact in ["Varian Medical Systems"]:
            show_instance_label = "RTImageLabel"
        else:
            show_instance_label = "InstanceNumber"

        try:
            pp = ii[show_instance_label]
            instance_num.append(pp)
        except:
            instance_num.append("Undefined")

    order = np.argsort(instance_datetime_order)

    return json.dumps({"1": list(np.asarray(instance_num)[order]), "2": num_instances,
                       "3": list(np.asarray(instance_datetime)[order]), "4": list(np.asarray(instances)[order])})

@app.route(WLWEB_FOLDER + '/winston_lutz_calculate/<s>/<w>/<c>', method="POST")
def winston_lutz_calculate(s, w, c):
    # Function that analyzes the images and sends results to the interface

    file_paths = RestToolbox.GetDcmZip(ORTHANC_URL, s)
    N = len(file_paths)
    clip_box = float(w)*10.0
    # If clip_box used, force edges to background value, save over original images
    if clip_box != 0:
        for subfolder in file_paths:    
            for filename in os.listdir(subfolder):
                try:
                    orig_img = pylinacimage.DicomImage(os.path.join(subfolder, filename))
                    orig_img.check_inversion() # Check inversion otherwise this might not work
                    clip_around_image(orig_img, clip_box)
                    orig_img.save(os.path.join(subfolder, filename))
                except:
                    return template("error_template", {"error_message": "Unable to apply clipbox.", "wlweb_folder": WLWEB_FOLDER})

    if N % 2 == 0:
        rows = int(N/2)
    else:
        rows = int(N//2) + 1

    cax_position = []
    bb_position = []
    cax2bb = []
    result = []
    radius = []
    SIDs = []
    lock = Lock()
    with lock:
        fig_wl, ax = plt.subplots(rows, 2, figsize=(8, 4*rows))
        ax = ax.flatten()
        cmap = plt.cm.Greys
        for o in range(N, len(ax), 1):
            fig_wl.delaxes(ax[o])
        for m in range(0, N, 1):
            try:
                wl = WinstonLutz(file_paths[m])
            except Exception as e:
                delete_files_in_path(file_paths)
                delete_figure([fig_wl])
                return template("error_template", {"error_message": "Module WinstonLutz cannot calculate. "
                                                   "Check image number "+str(m+1)+". "+str(e),
                                                   "wlweb_folder": WLWEB_FOLDER})

            img = wl.images[0]
            array = img.array
            dpmm = img.dpmm

            cax_position.append([-(img.epid.x-img.field_cax.x)/dpmm, -(img.epid.y-img.field_cax.y)/dpmm])
            bb_position.append([-(img.epid.x-img.bb.x)/dpmm, -(img.epid.y-img.bb.y)/dpmm])
            vec = [(img.field_cax.x - img.bb.x)/dpmm, (img.field_cax.y - img.bb.y)/dpmm]  # From BB to CAX (BB in the center)
            cax2bb.append(vec)

            SIDs.append(img.sid)
            # Plot the array and the contour of the 50 percent isodose line
            ax[m].imshow(np.flipud(array), cmap=cmap, interpolation="none",  origin='lower')
            level = np.average(np.percentile(array, [5, 99.9]))
            ax[m].contour(array, levels=[level], colors = ["blue"])  # CAX
            # Plot centers: field, BB, EPID
            ax[m].plot(img.field_cax.x, img.field_cax.y, 'b+', markersize=24, markeredgewidth=3, zorder=2)
            ax[m].plot(img.bb.x, img.bb.y, 'r+', markersize=24, markeredgewidth=3, zorder=2)
            ax[m].plot(img.epid.x, img.epid.y, 'yo', ms=10, markeredgewidth=0.0, zorder=1)

            # Plot edges of uncliped area with a line:
            if clip_box != 0:
                n_t = int((img.shape[0] + clip_box*img.dpmm)/2)  # Top  edge
                n_b = int((img.shape[0] - clip_box*img.dpmm)/2)  # bottom edge
                n_l = int((img.shape[1] - clip_box*img.dpmm)/2)  # Left  edge
                n_r = int((img.shape[1] + clip_box*img.dpmm)/2)  #  right edge
                ax[m].plot([n_l, n_l, n_r, n_r, n_l], [n_b, n_t, n_t, n_b, n_b], "-g")

            if c == "True":
                # If zoom is used:
                ax[m].set_ylim(img.bounding_box[0], img.bounding_box[1])
                ax[m].set_xlim(img.bounding_box[2], img.bounding_box[3])
                ax[m].autoscale(False)
            else:
                ax[m].autoscale(True)

            result.append([vec[0], vec[1]])
            radius.append(np.sqrt(vec[0]*vec[0] + vec[1]*vec[1]))
            ax[m].set_title(str(m+1)+". dx = "+str(round(vec[0], 2))+" mm,  dy = "+str(round(vec[1], 2))+" mm")

        fig_wl.tight_layout()
        script = mpld3.fig_to_html(fig_wl, d3_url=D3_URL, mpld3_url=MPLD3_URL)
        delete_figure([fig_wl])

        # Add scatter plot for the diagram
        fig_focal, ax_focal = plt.subplots(figsize=(6, 6))
        cax2bb = np.asarray(cax2bb)

        colors = ["blue"]*N
        labels = ['Img = {:d}, x = {:04.2f} mm, y = {:04.2f} mm, R = {:04.2f} mm'.format(i+1, cax2bb[i, 0], cax2bb[i, 1], np.linalg.norm(cax2bb[i, :])) for i in range(N)]
        ax_focal.scatter(cax2bb[:,0], cax2bb[:, 1], c=colors, alpha=0.5,  s=60, zorder=1, linewidths=1)
        scatter = ax_focal.plot(cax2bb[:,0], cax2bb[:, 1], linestyle="-", color="green", alpha=0.5, marker="o", zorder=2,  markerfacecolor='none', markeredgecolor='none')
        tooltip = mpld3.plugins.PointLabelTooltip(scatter[0], labels=labels, location="top left")
        mpld3.plugins.connect(fig_focal, tooltip)

        limits_focal = 1.5 # Define the extent of the diagram
        p = ax_focal.plot([0],[0], "r+", mew=3, ms=15)
        tooltip2 = mpld3.plugins.PointLabelTooltip(p[0], labels=["Ballbearing"], location="top left")
        mpld3.plugins.connect(fig_focal, tooltip2)
        ax_focal.add_patch(patches.Circle((0, 0), PASS_RATE, color='r', linestyle="dashed", fill=False))
        ax_focal.add_patch(patches.Circle((0, 0), SUCCESS_RATE, color='r', linestyle="dashed", fill=False))
        ax_focal.autoscale(False)
        ax_focal.set_xlim([-limits_focal, limits_focal])
        ax_focal.set_ylim([-limits_focal, limits_focal])
        ax_focal.set_title("CAX to BB distance")
        ax_focal.set_xlabel("X [mm]")
        ax_focal.set_ylabel("Y [mm]")
        fig_focal.tight_layout()

        script_focal = mpld3.fig_to_html(fig_focal, d3_url=D3_URL, mpld3_url=MPLD3_URL)
        delete_figure([fig_focal])

    # Calculate average radius from center of CAX cloud to CAX:
    average_x = np.average(cax2bb[:, 0])
    average_y = np.average(cax2bb[:, 1])
    cax_wobble = np.linalg.norm(np.column_stack((cax2bb[:, 0]-average_x, cax2bb[:, 1]-average_y)), axis=1)

    delete_files_in_path(file_paths) # Delete temporary images (all subfolders)
    variables = {
                 "script": script,
                 "script_focal": script_focal,
                 "cax_position": cax_position,
                 "bb_position": bb_position,
                 "result": result,
                 "max_deviation": round(np.max(radius), 2),
                 "average_x": round(average_x, 2),
                 "average_y": round(average_y, 2),
                 "sigma_x": round(np.std(cax2bb[:, 0]), 2),
                 "sigma_y": round(np.std(cax2bb[:, 1]), 2),
                 "cax_wobble_avg": round(np.average(cax_wobble), 2),
                 "cax_wobble_sigma": round(np.std(cax_wobble), 2),
                 "radius": radius,
                 "pass_rate": PASS_RATE,
                 "success_rate": SUCCESS_RATE,
                 "SIDs": list(set(SIDs))
                 }
    gc.collect() # Collect and delete mpl plots
    return template("WinstonLutzResult", variables)

if __name__ == '__main__':
    app.run(host=IP_ADDRESS, port=PORT, reloader=True, server="cherrypy", debug=False)
